from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

data = {} #хранение данных о пользователе
test_config = {} #параметры теста

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        #заносим данные пользователя
        data['name'] = request.form['name']
        data['age'] = request.form['age']

        return redirect(url_for('success'))

    return render_template('registration.html')

@app.route('/success', methods=['GET', 'POST'])
def success():
  if request.method == 'POST':
    #заносим данные о тесте
    test_config['priv'] = request.form.get('type') == 'priv' #выбрал ли пользователь приведенные уравнения
    test_config['count'] = request.form['count']  #значение count

    return redirect(url_for('test'))

  return render_template('parameters.html', data=data)

@app.route('/test')
def test():
    return render_template('test.html')

if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1', debug=True)

